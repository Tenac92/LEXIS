
-- Drop existing table if exists
DROP TABLE IF EXISTS budget_na853_split CASCADE;

-- Create budget table with proper constraints
CREATE TABLE budget_na853_split (
    id SERIAL PRIMARY KEY,
    na853 VARCHAR(20) NOT NULL UNIQUE,
    mis VARCHAR(20),
    proip DECIMAL(15,2) DEFAULT 0,
    ethsia_pistosi DECIMAL(15,2) DEFAULT 0,
    q1 DECIMAL(15,2) DEFAULT 0,
    q2 DECIMAL(15,2) DEFAULT 0,
    q3 DECIMAL(15,2) DEFAULT 0,
    q4 DECIMAL(15,2) DEFAULT 0,
    katanomes_etous DECIMAL(15,2) DEFAULT 0,
    user_view DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_amounts CHECK (
        proip >= 0 AND
        ethsia_pistosi >= 0 AND
        q1 >= 0 AND q2 >= 0 AND q3 >= 0 AND q4 >= 0 AND
        katanomes_etous >= 0 AND
        user_view >= 0
    )
);

-- Create index for faster lookups
CREATE INDEX idx_budget_na853 ON budget_na853_split(na853);
CREATE INDEX idx_budget_mis ON budget_na853_split(mis);

-- Create trigger to update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_budget_updated_at
    BEFORE UPDATE ON budget_na853_split
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
