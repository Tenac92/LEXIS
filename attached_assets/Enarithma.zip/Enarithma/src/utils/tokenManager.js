
const jwt = require('jsonwebtoken');
const config = require('../config/config.js');

class TokenManager {
  static generateToken(user) {
    return jwt.sign(
      { userId: user.id, email: user.email },
      config.jwtSecret,
      { expiresIn: '24h' }
    );
  }

  static verifyToken(token) {
    try {
      return jwt.verify(token, config.jwtSecret);
    } catch (error) {
      throw new Error('Invalid token');
    }
  }

  static decodeToken(token) {
    try {
      return jwt.decode(token);
    } catch (error) {
      throw new Error('Token decode failed');
    }
  }
}

module.exports = TokenManager;
