
const { supabase } = require('../config/db');

class AuditLogger {
  static async log(userId, actionType, entityType, entityId, details = {}) {
    try {
      const { error } = await supabase
        .from('audit_logs')
        .insert({
          user_id: userId,
          action_type: actionType,
          entity_type: entityType,
          entity_id: entityId,
          details,
          ip_address: details.ip_address,
          user_agent: details.user_agent
        });

      if (error) throw error;
    } catch (err) {
      console.error('Audit logging failed:', err);
      throw err;
    }
  }

  static async getAuditLogs(filters = {}) {
    try {
      const query = supabase
        .from('audit_logs')
        .select(`
          *,
          users (name, email)
        `)
        .order('created_at', { ascending: false });

      if (filters.userId) query.eq('user_id', filters.userId);
      if (filters.entityType) query.eq('entity_type', filters.entityType);
      if (filters.fromDate) query.gte('created_at', filters.fromDate);
      if (filters.toDate) query.lte('created_at', filters.toDate);

      const { data, error } = await query;
      if (error) throw error;
      return data;
    } catch (err) {
      console.error('Failed to fetch audit logs:', err);
      throw err;
    }
  }
}

module.exports = AuditLogger;
