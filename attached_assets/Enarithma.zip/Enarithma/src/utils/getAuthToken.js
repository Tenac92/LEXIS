
const jwt = require('jsonwebtoken');
const { ApiError } = require('./apiErrorHandler.js');

/**
 * Extract and validate JWT token from request headers
 * @param {Object} req - Express request object
 * @returns {string|null} Valid JWT token or null
 */
const getAuthToken = (req) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
      throw new ApiError(401, 'Authorization header missing');
    }
    
    if (!authHeader.startsWith('Bearer ')) {
      throw new ApiError(401, 'Invalid authorization format - Bearer required');
    }

    const token = authHeader.split(' ')[1];
    if (!token) {
      throw new ApiError(401, 'Token missing from authorization header');
    }

    // Basic JWT format validation
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new ApiError(401, 'Invalid token format');
    }

    // Verify token hasn't been tampered with
    try {
      const decoded = jwt.decode(token);
      if (!decoded) {
        throw new ApiError(401, 'Invalid token payload');
      }

      // Check token expiration
      const currentTime = Math.floor(Date.now() / 1000);
      if (decoded.exp && decoded.exp < currentTime) {
        throw new ApiError(401, 'Token has expired');
      }

      return token;
    } catch (error) {
      throw new ApiError(401, 'Token validation failed');
    }
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    throw new ApiError(500, 'Token processing error');
  }
};

module.exports = getAuthToken;
