
const validateBudgetData = (data) => {
  const errors = [];
  const validTypes = ['funding', 'reallocation'];
  
  if (!data || typeof data !== 'object') {
    return { isValid: false, errors: ['Invalid data format'] };
  }

  if (!validTypes.includes(data.type)) {
    errors.push(`Invalid notification type. Must be one of: ${validTypes.join(', ')}`);
  }

  if (!data.mis?.toString().trim()) {
    errors.push('MIS identifier is required');
  }

  const numericFields = {
    amount: 'Amount',
    current_budget: 'Current budget',
    ethsia_pistosi: 'Ethsia pistosi'
  };

  Object.entries(numericFields).forEach(([field, label]) => {
    const value = parseFloat(data[field]);
    if (isNaN(value)) {
      errors.push(`${label} must be a valid number`);
    } else if (value < 0) {
      errors.push(`${label} cannot be negative`);
    }
  });

  return {
    isValid: errors.length === 0,
    errors
  };
};

module.exports = { validateBudgetData };
