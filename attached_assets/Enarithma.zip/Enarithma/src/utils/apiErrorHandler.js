class ApiError extends Error {
  constructor(status, message, code = 'INTERNAL_ERROR') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

class ApiErrorHandler {
  static handleError(err, req, res) {
    if (err instanceof ApiError) {
      return res.status(err.status).json({
        status: 'error',
        message: err.message,
        code: err.code
      });
    }

    console.error('Unhandled error:', err);
    return res.status(500).json({
      status: 'error',
      message: 'Internal server error',
      code: 'INTERNAL_ERROR'
    });
  }
}

module.exports = { ApiError, ApiErrorHandler };