
class Cache {
  constructor(options = {}) {
    this.store = new Map();
    this.ttl = options.ttl || 300000; // 5 minutes default
    this.maxSize = options.maxSize || 1000;
    this.maxMemory = options.maxMemory || 100 * 1024 * 1024; // 100MB default
    this.cleanupInterval = options.cleanupInterval || 60000; // 1 minute
    this.totalMemoryUsage = 0;
    this.invalidationPatterns = new Map();
    this._startCleanup();
  }

  calculateSize(value) {
    const stringify = JSON.stringify(value);
    return new TextEncoder().encode(stringify).length;
  }

  addInvalidationPattern(pattern, keys) {
    this.invalidationPatterns.set(pattern, keys);
  }

  set(key, value, ttl = this.ttl) {
    if (this.store.size >= this.maxSize) {
      this._removeOldest();
    }

    this.store.set(key, {
      value,
      expires: Date.now() + ttl,
      lastAccessed: Date.now()
    });
    return value;
  }

  get(key) {
    const item = this.store.get(key);
    if (!item) return null;

    if (Date.now() > item.expires) {
      this.store.delete(key);
      return null;
    }

    item.lastAccessed = Date.now();
    return item.value;
  }

  delete(key) {
    return this.store.delete(key);
  }

  clear() {
    this.store.clear();
  }

  _removeOldest() {
    let oldest = Infinity;
    let oldestKey = null;

    for (const [key, item] of this.store.entries()) {
      if (item.lastAccessed < oldest) {
        oldest = item.lastAccessed;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.store.delete(oldestKey);
    }
  }

  _startCleanup() {
    setInterval(() => {
      const now = Date.now();
      for (const [key, item] of this.store.entries()) {
        if (now > item.expires) {
          this.store.delete(key);
        }
      }
    }, this.cleanupInterval);
  }
}

module.exports = new Cache();
