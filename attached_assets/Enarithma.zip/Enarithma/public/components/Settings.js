
import React, { useState, useEffect } from 'react';
import { TokenManager } from '../utils/tokenManager.js';

function Settings() {
  const [settings, setSettings] = useState({
    notifications: true,
    emailUpdates: true,
    language: 'el',
    theme: 'light'
  });
  const [loading, setLoading] = useState(true);
  const [success, setSuccess] = useState(false);
  const tokenManager = TokenManager.getInstance();

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const token = await tokenManager.getToken();
        const response = await API.request('/api/users/settings');
        const data = await response.json();
        setSettings(data);
      } catch (error) {
        console.error('Failed to load settings:', error);
      } finally {
        setLoading(false);
      }
    };

    loadSettings();
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = await tokenManager.getToken();
      const response = await fetch('/api/users/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(settings)
      });

      if (response.ok) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      }
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  };

  if (loading) return <div>Loading settings...</div>;

  return React.createElement('div', 
    { className: 'max-w-2xl mx-auto p-6' },
    [
      React.createElement('h2', 
        { className: 'text-2xl font-bold mb-6', key: 'title' }, 
        'Settings'
      ),
      React.createElement('form', 
        { 
          onSubmit: handleSubmit, 
          className: 'space-y-6',
          key: 'form'
        },
        [
          React.createElement('div', 
            { className: 'space-y-4', key: 'settings-group' },
            [
              React.createElement('div', 
                { className: 'flex items-center justify-between', key: 'notifications' },
                [
                  React.createElement('label', 
                    { className: 'font-medium', key: 'notifications-label' }, 
                    'Notifications'
                  ),
                  React.createElement('input', {
                    type: 'checkbox',
                    name: 'notifications',
                    checked: settings.notifications,
                    onChange: handleChange,
                    className: 'h-4 w-4 text-blue-600',
                    key: 'notifications-input'
                  })
                ]
              ),
              React.createElement('div', 
                { className: 'flex items-center justify-between', key: 'email-updates' },
                [
                  React.createElement('label', 
                    { className: 'font-medium', key: 'email-label' }, 
                    'Email Updates'
                  ),
                  React.createElement('input', {
                    type: 'checkbox',
                    name: 'emailUpdates',
                    checked: settings.emailUpdates,
                    onChange: handleChange,
                    className: 'h-4 w-4 text-blue-600',
                    key: 'email-input'
                  })
                ]
              ),
              React.createElement('div', 
                { key: 'language' },
                [
                  React.createElement('label', 
                    { className: 'font-medium block mb-2', key: 'language-label' }, 
                    'Language'
                  ),
                  React.createElement('select', {
                    name: 'language',
                    value: settings.language,
                    onChange: handleChange,
                    className: 'w-full p-2 border rounded',
                    key: 'language-select'
                  }, [
                    React.createElement('option', { value: 'el', key: 'el' }, 'Ελληνικά'),
                    React.createElement('option', { value: 'en', key: 'en' }, 'English')
                  ])
                ]
              ),
              React.createElement('div', 
                { key: 'theme' },
                [
                  React.createElement('label', 
                    { className: 'font-medium block mb-2', key: 'theme-label' }, 
                    'Theme'
                  ),
                  React.createElement('select', {
                    name: 'theme',
                    value: settings.theme,
                    onChange: handleChange,
                    className: 'w-full p-2 border rounded',
                    key: 'theme-select'
                  }, [
                    React.createElement('option', { value: 'light', key: 'light' }, 'Light'),
                    React.createElement('option', { value: 'dark', key: 'dark' }, 'Dark')
                  ])
                ]
              )
            ]
          ),
          React.createElement('div', 
            { className: 'flex items-center justify-between', key: 'actions' },
            [
              React.createElement('button', {
                type: 'submit',
                className: 'bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700',
                key: 'submit'
              }, 'Save Settings'),
              success && React.createElement('span', {
                className: 'text-green-600',
                key: 'success'
              }, 'Settings saved successfully!')
            ]
          )
        ]
      )
    ]
  );
}

export default Settings;
