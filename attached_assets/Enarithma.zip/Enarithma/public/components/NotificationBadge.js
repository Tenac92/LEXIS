
import React from 'react';

function NotificationBadge({ count }) {
  if (!count || count === 0) return null;
  
  return React.createElement('span',
    {
      className: 'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center'
    },
    count > 99 ? '99+' : count
  );
}

export default NotificationBadge;
