
import { API } from "../../utils/api.js";
import { getAuthToken } from "../../utils/auth.js";
import { ErrorHandler } from "../../utils/errorHandler.js";

export class BudgetManager {
  constructor() {
    this.modal = null;
    this.validateCache = new Map();
    this.initialized = false;
    this.budgetData = null;
  }

  initialize(modal) {
    if (!modal) {
      throw new Error("Modal is required for initialization");
    }
    this.modal = modal;
    this.initialized = true;
    return true;
  }

  async loadBudgetData(mis) {
    try {
      if (!this.initialized) {
        throw new Error("BudgetManager not initialized");
      }

      if (!mis?.toString().trim()) {
        throw new Error("Invalid MIS code");
      }

      const token = await getAuthToken();
      const eventSource = new EventSource(`/api/budget/updates?auth_token=${token}&mis=${mis}`);
      
      eventSource.onmessage = (event) => {
        const budgetData = JSON.parse(event.data);
        this.budgetData = budgetData;
        if (this.modal) {
          this.updateBudgetIndicators(this.calculateTotalAmount(), budgetData);
        }
      };

      eventSource.onerror = (error) => {
        console.error('SSE Error:', error);
        eventSource.close();
      };

      // Store eventSource for cleanup
      this.eventSource = eventSource;

      // Initial load
      const response = await fetch(`/api/budget/${mis}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to load budget data: ${response.statusText}`);
      }

      const budgetData = await response.json();
      this.budgetData = budgetData;

      return {
        budgetAmount: parseFloat(budgetData.user_view) || 0,
        ethsiaPistosi: parseFloat(budgetData.ethsia_pistosi) || 0,
        budgetData
      };
    } catch (error) {
      console.error("Error loading budget data:", error);
      ErrorHandler.showError(`Failed to load budget data: ${error.message}`);
      return null;
    }
  }

  async validateBudgetAmount(amount, mis) {
    try {
      if (!this.initialized) {
        throw new Error("BudgetManager not initialized");
      }

      const parsedAmount = parseFloat(amount);
      if (!parsedAmount || isNaN(parsedAmount) || parsedAmount <= 0) {
        throw new Error("Invalid amount value");
      }

      if (!mis?.toString().trim()) {
        throw new Error("Invalid MIS code");
      }

      const cacheKey = `${mis}-${parsedAmount}`;
      if (this.validateCache.has(cacheKey)) {
        return this.validateCache.get(cacheKey);
      }

      const token = await getAuthToken();
      const response = await fetch(`/api/budget/${mis}/validate-amount`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ amount: parsedAmount }),
      });

      if (!response.ok) {
        throw new Error(`Budget validation failed: ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.requiresNotification) {
        const notificationResult = await this.sendAdminNotification(mis, parsedAmount, data);
        if (!notificationResult.success) {
          throw new Error(`Admin notification failed: ${notificationResult.message}`);
        }
      }

      const result = {
        canCreate: data.canCreate,
        message: data.message,
        allowDocx: data.allowDocx,
        requiresNotification: data.requiresNotification,
        notificationType: data.notificationType
      };

      this.validateCache.set(cacheKey, result);
      return result;

    } catch (error) {
      console.error("Budget validation error:", error);
      ErrorHandler.showError(error.message);
      return {
        canCreate: false,
        message: error.message,
        allowDocx: false
      };
    }
  }

  async sendAdminNotification(mis, amount, validationData) {
    try {
      // Enhanced input validation
      if (!mis || !amount || !validationData) {
        throw new Error('Missing required notification data');
      }

      // Ensure numeric values are valid
      const parsedAmount = parseFloat(amount);
      const currentBudget = parseFloat(this.budgetData?.user_view || 0);
      const ethsiaPistosi = parseFloat(this.budgetData?.ethsia_pistosi || 0);

      if (isNaN(parsedAmount) || isNaN(currentBudget) || isNaN(ethsiaPistosi)) {
        throw new Error('Invalid numeric values in notification data');
      }

      if (isNaN(parsedAmount) || isNaN(currentBudget) || isNaN(ethsiaPistosi)) {
        throw new Error('Invalid numeric values in notification data');
      }

      const notificationData = {
        type: validationData.notificationType || 'reallocation',
        mis: mis.toString(),
        amount: parsedAmount,
        current_budget: currentBudget,
        ethsia_pistosi: ethsiaPistosi,
        reason: validationData.message || 'Budget limit exceeded',
        status: 'pending'
      };

      console.log('Sending notification data:', notificationData);

      const token = await getAuthToken();
      const response = await fetch('/api/budget/notify-admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(notificationData)
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || 'Admin notification failed');
      }

      // Log successful notification
      console.log('Admin notification sent successfully:', {
        mis,
        amount: parsedAmount,
        type: validationData.notificationType
      });

      return {
        success: true,
        notificationId: result.notification_id,
        projectStatus: result.project_status,
        message: result.message
      };
    } catch (error) {
      console.error("Admin notification error:", error);
      return {
        success: false,
        message: error.message
      };
    }
  }

  updateBudgetIndicators(amount, budgetData) {
    if (!this.initialized || !this.modal) {
      console.warn('BudgetManager not properly initialized');
      return;
    }

    if (!budgetData) {
      console.warn('Budget data is missing');
      return;
    }

    const update = async () => {
      let container = this.modal.querySelector("#budget-indicators-container");
      if (!container) return false;
      
      // Clear existing indicators
      container.innerHTML = '';
      
      // Create new indicators container
      const indicatorsContainer = document.createElement('div');
      indicatorsContainer.className = 'budget-indicators';
      container.appendChild(indicatorsContainer);
      if (!container) {
        console.warn('Budget indicators container not found after retries');
        return false;
      }

      try {
        this.updateBudgetValues(container, amount, budgetData);
        return true;
      } catch (error) {
        console.error('Error updating budget values:', error);
        return false;
      }
    };

    // Initial attempt
    if (update()) return;

    // If failed, retry with increasing delays
    let attempts = 0;
    const maxAttempts = 10;
    const retryUpdate = () => {
      if (attempts >= maxAttempts) {
        console.error('Failed to update budget indicators after max attempts');
        return;
      }

      setTimeout(() => {
        if (!update()) {
          attempts++;
          retryUpdate();
        }
      }, Math.min(100 * Math.pow(1.5, attempts), 2000)); // Exponential backoff with max 2s
    };

    retryUpdate();
  }

  updateBudgetValues(container, amount, budgetData) {
    if (!container || !budgetData) return;

    try {
      // Ensure proper number parsing with fallbacks
      const parsedAmount = Math.max(0, parseFloat(amount) || 0);
      const userView = Math.max(0, parseFloat(budgetData.user_view) || 0);
      const ethsiaPistosi = Math.max(0, parseFloat(budgetData.ethsia_pistosi) || 0);
      const proip = Math.max(0, parseFloat(budgetData.proip) || 0);

      // Calculate remaining amounts
      const remainingUserView = Math.max(0, userView - parsedAmount);
      const remainingEthsia = Math.max(0, ethsiaPistosi - parsedAmount);

      // Calculate percentages with bounds checking
      const percentageUsed = userView > 0 ? Math.min(100, (parsedAmount / userView) * 100) : 0;
      const percentageOfEthsia = ethsiaPistosi > 0 ? Math.min(100, (parsedAmount / ethsiaPistosi) * 100) : 0;

      container.innerHTML = `
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 relative">
          <div class="absolute -top-4 right-0 text-sm font-medium ${
            parsedAmount > userView ? 'text-red-600' : 'text-green-600'
          }">
            Total Amount: €${parsedAmount.toLocaleString('el-GR', {minimumFractionDigits: 2, maximumFractionDigits: 2})}
          </div>
          <div class="budget-indicator-item p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg bg-blue-100/50 flex items-center justify-center">
                  <i class="fas fa-wallet text-blue-600"></i>
                </div>
                <div>
                  <span class="text-sm font-medium text-gray-600">Διαθέσιμο Υπόλοιπο</span>
                  <div class="text-lg font-bold text-blue-600">€${userView.toLocaleString()}</div>
                </div>
              </div>
            </div>
            <div class="space-y-2">
              <div class="flex justify-between text-sm">
                <span class="text-gray-500">Χρήση</span>
                <span class="font-medium ${percentageUsed > 80 ? 'text-red-600' : 'text-gray-700'}">${percentageUsed.toFixed(1)}%</span>
              </div>
              <div class="h-2.5 bg-gray-100 rounded-full overflow-hidden shadow-inner">
                <div class="h-full ${
                  percentageUsed > 90 ? 'bg-red-500' : 
                  percentageUsed > 80 ? 'bg-orange-500' : 
                  'bg-blue-500'
                } rounded-full transition-all duration-500 relative" 
                     style="width: ${Math.min(percentageUsed, 100)}%">
                  <div class="absolute inset-0 bg-white/20 animate-pulse"></div>
                </div>
              </div>
              <div class="mt-2 text-xs text-gray-500 flex justify-between">
                <span>Remaining: €${remainingUserView.toLocaleString()}</span>
                <span class="${
                  remainingUserView < 1000 ? 'text-red-500 font-medium' : ''
                }">Used: €${(userView - remainingUserView).toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div class="budget-indicator-item p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg bg-green-100/50 flex items-center justify-center">
                  <i class="fas fa-coins text-green-600"></i>
                </div>
                <div>
                  <span class="text-sm font-medium text-gray-600">Ετήσια Πίστωση</span>
                  <div class="text-lg font-bold text-green-600">€${ethsiaPistosi.toLocaleString()}</div>
                </div>
              </div>
            </div>
            <div class="space-y-2">
              <div class="flex justify-between text-sm">
                <span class="text-gray-500">Χρήση</span>
                <span class="font-medium ${percentageOfEthsia > 80 ? 'text-red-600' : 'text-gray-700'}">${percentageOfEthsia.toFixed(1)}%</span>
              </div>
              <div class="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div class="h-full ${percentageOfEthsia > 80 ? 'bg-red-500' : 'bg-green-500'} rounded-full transition-all duration-500" 
                     style="width: ${Math.min(percentageOfEthsia, 100)}%"></div>
              </div>
            </div>
          </div>

          <div class="budget-indicator-item p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <div class="w-8 h-8 rounded-lg bg-purple-100/50 flex items-center justify-center">
                  <i class="fas fa-chart-line text-purple-600"></i>
                </div>
                <div>
                  <span class="text-sm font-medium text-gray-600">Προϋπολογισμός (ΠΡΟΫΠ)</span>
                  <div class="text-lg font-bold text-purple-600">€${proip.toLocaleString()}</div>
                </div>
              </div>
            </div>
            <div class="mt-2 text-sm text-gray-500">
              Συνολικός προϋπολογισμός έργου
            </div>
          </div>
        </div>
      `;
    } catch (error) {
      console.error("Error updating budget values:", error);
    }
  }

  clearCache() {
    this.validateCache.clear();
  }
}
