import { API } from "../../utils/api.js";
import { getAuthToken, getUserFromToken } from "../../utils/auth.js";
import { BaseModal } from "./BaseModal.js";
import { ErrorHandler } from "../../utils/errorHandler.js";
import { BudgetManager } from "./BudgetManager.js";
import { ValidationManager } from "./ValidationManager.js";
import { sseService } from "../../utils/sseService.js";

export class CreateDocumentModal extends BaseModal {
  constructor(mainManager) {
    super("createDocumentModal");
    this.manager = mainManager;
    this.currentStep = 0;
    this.initialized = false;
    this.state = this.getInitialState();
    this.budgetManager = new BudgetManager();
    this.validationManager = new ValidationManager();
    this.stepTitles = ['Επιλογή Μονάδας', 'Στοιχεία Έργου', 'Στοιχεία Παραληπτών', 'Συνημμένα'];
    this.eventHandlers = new Map();
    this.debounceTimers = new Map();
  }

  getInitialState() {
    return {
      unit: "",
      project: "",
      project_na853: "",
      expenditure_type: "",
      recipients: [],
      attachments: [],
      loading: false,
      validationErrors: new Map(),
      selectedFiles: new Map(),
      selectedMIS: "",
      budgetAmount: 0,
      ethsiaPistosi: 0,
      allowDocx: true,
      projectStatus: "active",
      budgetDataLoaded: false,
      budgetData: null,
      hasUnsavedChanges: false,
      selectedAttachments: []
    };
  }

  async initialize() {
    try {
      if (this.initialized) return true;

      await this.waitForDOMReady();
      await this.initializeBaseModal();
      await this.initializeManagers();
      await this.setupInitialUI();
      await this.setupEventHandlers();

      this.initialized = true;
      return true;
    } catch (error) {
      console.error("Initialization failed:", error);
      ErrorHandler.showError("Failed to initialize modal: " + error.message);
      return false;
    }
  }

  async waitForDOMReady() {
    if (document.readyState === 'complete') return;
    return new Promise(resolve => {
      window.addEventListener('load', resolve, { once: true });
    });
  }

  async initializeBaseModal() {
    const initResult = await Promise.race([
      super.initialize(),
      new Promise((_, reject) => setTimeout(() => 
        reject(new Error('Modal initialization timed out')), 5000))
    ]);

    if (!initResult) throw new Error("Failed to initialize base modal");
  }

  async initializeManagers() {
    await Promise.all([
      this.budgetManager.initialize(this.modal),
      this.validationManager.initialize(this.modal)
    ]);
  }

  async setupInitialUI() {
    this.setTitle("Δημιουργία Νέου Εγγράφου");
    await this.renderCurrentStep();
    this.setupKeyboardShortcuts();
    this.setupUnsavedChangesHandler();
  }

  setupEventHandlers() {
    this.setupModalEventListeners();
    this.setupFormValidation();
  }

  setupModalEventListeners() {
    const handlers = {
      'click': this.handleModalClick.bind(this),
      'input': this.handleModalInput.bind(this),
      'change': this.handleModalChange.bind(this)
    };

    Object.entries(handlers).forEach(([event, handler]) => {
      this.modal?.addEventListener(event, handler);
      this.eventHandlers.set(event, handler);
    });

    const addRecipientBtn = this.modal?.querySelector('#addRecipientBtn');
    if (addRecipientBtn) {
      const handler = () => this.addRecipient();
      addRecipientBtn.addEventListener('click', handler);
      this.eventHandlers.set('addRecipient', handler);
    }
  }

  setupFormValidation() {
    this.validateFields = this.debounce(async () => {
      if (this.currentStep === 2) {
        const totalAmount = this.calculateTotalAmount();
        const validation = await this.budgetManager.validateBudgetAmount(
          totalAmount, 
          this.state.selectedMIS
        );

        if (!validation.canCreate) {
          ErrorHandler.showError(validation.message);
          return false;
        }
      }
      return true;
    }, 300);
  }

  debounce(fn, delay) {
    return (...args) => {
      const key = fn.toString();
      if (this.debounceTimers.has(key)) {
        clearTimeout(this.debounceTimers.get(key));
      }
      this.debounceTimers.set(key, setTimeout(() => {
        fn.apply(this, args);
        this.debounceTimers.delete(key);
      }, delay));
    };
  }

  async validateCurrentStep() {
    const validators = {
      0: () => this.validationManager.validateUnitStep(this.state.unit),
      1: () => this.validationManager.validateProjectStep(
        this.state.project, 
        this.state.expenditure_type
      ),
      2: () => this.validateRecipientsStep(),
      3: () => ({ valid: true })
    };

    const validator = validators[this.currentStep];
    if (!validator) throw new Error("Invalid step");

    const result = await validator();
    if (!result.valid) {
      ErrorHandler.showError(result.message);
      return false;
    }
    return true;
  }

  async validateRecipientsStep() {
    if (!this.state.recipients.length) {
      return { 
        valid: false, 
        message: "Απαιτείται τουλάχιστον ένας παραλήπτης" 
      };
    }

    for (let i = 0; i < this.state.recipients.length; i++) {
      const validation = await this.validateRecipient(this.state.recipients[i], i);
      if (!validation.valid) return validation;
    }

    return await this.validateBudget();
  }

  async validateRecipient(recipient, index) {
    const fields = {
      firstname: {
        validate: val => val?.trim().length >= 2,
        message: "Το όνομα πρέπει να έχει τουλάχιστον 2 χαρακτήρες"
      },
      lastname: {
        validate: val => val?.trim().length >= 2,
        message: "Το επώνυμο πρέπει να έχει τουλάχιστον 2 χαρακτήρες"
      },
      afm: {
        validate: val => /^\d{9}$/.test(val?.trim()),
        message: "Το ΑΦΜ πρέπει να έχει 9 ψηφία"
      },
      amount: {
        validate: val => !isNaN(val) && parseFloat(val) > 0,
        message: "Μη έγκυρο ποσό"
      }
    };

    for (const [field, { validate, message }] of Object.entries(fields)) {
      if (!validate(recipient[field])) {
        this.highlightInvalidField(index, field);
        return { 
          valid: false, 
          message: `Παραλήπτης ${index + 1}: ${message}` 
        };
      }
    }

    return { valid: true };
  }

  async validateBudget() {
    const totalAmount = this.calculateTotalAmount();
    const budgetValidation = await this.budgetManager.validateBudgetAmount(
      totalAmount, 
      this.state.selectedMIS
    );

    if (!budgetValidation.canCreate) {
      return { 
        valid: false, 
        message: budgetValidation.message || "Budget validation failed" 
      };
    }

    this.state.allowDocx = budgetValidation.allowDocx !== false;
    return { valid: true };
  }

  calculateTotalAmount() {
    return this.state.recipients.reduce((sum, r) => 
      sum + (parseFloat(r.amount) || 0), 0
    );
  }

  async submitForm() {
    if (this.state.loading) return;

    try {
      this.state.loading = true;
      this.updateSubmitButton(true);

      const formData = this.prepareFormData();
      await this.validateFormData(formData);

      const response = await API.createDocument(formData, this.state.unit);
      await this.handleFormSubmissionSuccess(response);
    } catch (error) {
      ErrorHandler.showError(error.message || "Failed to create document");
    } finally {
      this.state.loading = false;
      this.updateSubmitButton(false);
    }
  }

  prepareFormData() {
    const user = getUserFromToken();
    if (!user?.department) {
      throw new Error("User department not found");
    }

    return {
      unit: this.state.unit,
      project_id: this.state.project,
      expenditure_type: this.state.expenditure_type,
      department: user.department,
      recipients: this.state.recipients.map(r => ({
        firstname: r.firstname?.trim(),
        lastname: r.lastname?.trim(),
        afm: r.afm?.trim(),
        amount: parseFloat(r.amount) || 0,
        installment: parseInt(r.installment) || 1,
        status: "pending"
      })),
      total_amount: this.calculateTotalAmount(),
      status: "pending",
      attachments: Array.from(this.state.selectedFiles.entries())
        .map(([type, file]) => ({
          type,
          file: file.name
        }))
    };
  }

  async validateFormData(formData) {
    const errors = [];

    if (!formData.unit) errors.push("Unit is required");
    if (!formData.project_id) errors.push("Project is required");
    if (!formData.expenditure_type) errors.push("Expenditure type is required");
    if (!formData.recipients.length) errors.push("At least one recipient is required");

    if (errors.length) {
      throw new Error(errors.join(", "));
    }
  }

  cleanup() {
    sseService.closeAll();
    this.eventHandlers.forEach((handler, event) => {
      this.modal?.removeEventListener(event, handler);
    });
    this.eventHandlers.clear();
    this.debounceTimers.forEach(timer => clearTimeout(timer));
    this.debounceTimers.clear();
    this.state = this.getInitialState();
    this.initialized = false;
  }

  async handleBudgetUpdate(data) {
    if (!this.state.budgetData || this.state.selectedMIS !== data.mis) return;

    // Update local budget data
    this.state.budgetData = {
      ...this.state.budgetData,
      available: data.available,
      total: data.total
    };

    // Refresh budget indicators if we're on the relevant step
    if (this.currentStep === 2) {
      const totalAmount = this.calculateTotalAmount();
      await this.budgetManager.updateBudgetIndicators(totalAmount, this.state.budgetData);
    }
  }

  setupUnsavedChangesHandler() {
    const handler = (e) => {
      if (this.state.hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', handler);
    this.eventHandlers.set('beforeunload', { type: 'beforeunload', fn: handler });
  }

  async setupSSEConnection() {
    try {
      if (!this.state.selectedMIS) {
        return; // Don't setup SSE if no MIS is selected
      }

      const url = `/api/budget/updates?mis=${encodeURIComponent(this.state.selectedMIS)}`;
      await sseService.createConnection(url, {
        onMessage: (data) => {
          if (data.type === 'budget_update' && data.mis === this.state.selectedMIS) {
            this.handleBudgetUpdate(data);
          }
        },
        onMaxRetriesReached: () => {
          ErrorHandler.showError('Lost connection to server. Please refresh the page.');
        }
      });
    } catch (error) {
      ErrorHandler.showError(error.message || 'Failed to setup SSE connection');
    }
  }


  handleModalClick(e) {
    const target = e.target;
    const deleteBtn = target.closest('.delete-recipient');
    const deleteAttachmentBtn = target.closest('.delete-attachment');

    if (target.closest('#addRecipientBtn')) {
      this.addRecipient();
    } else if (deleteBtn) {
      const index = parseInt(deleteBtn.dataset.index);
      if (!isNaN(index)) this.removeRecipient(index);
    } else if (deleteAttachmentBtn) {
      const type = deleteAttachmentBtn.dataset.type;
      if (type) {
        this.state.selectedFiles.delete(type);
        this.state.hasUnsavedChanges = true;
        this.renderCurrentStep();
      }
    } else if (target.matches('.prev-step')) {
      this.previousStep();
    } else if (target.matches('.next-step')) {
      this.nextStep();
    }
  }

  handleModalInput(e) {
    const target = e.target;

    if (target.matches('.recipient-input')) {
      this.handleRecipientInput(target);
    }
  }

  handleModalChange(e) {
    const target = e.target;

    if (target.matches('#projectSelect')) {
      this.handleProjectChange(target.value);
    } else if (target.matches('#expenditureType')) {
      this.handleExpenditureTypeChange(target.value);
    } else if (target.matches('.attachment-input')) {
      this.handleAttachmentChange(e);
    }
  }

  async handleProjectChange(value) {
    try {
      if (!value) return;

      // Disable inputs during loading
      const projectSelect = this.modal?.querySelector('#projectSelect');
      const expTypeSelect = this.modal?.querySelector('#expTypeSelect');
      if (projectSelect) projectSelect.disabled = true;
      if (expTypeSelect) expTypeSelect.disabled = true;

      // Set initial state
      this.state.project = value;
      this.state.selectedMIS = value;
      this.state.hasUnsavedChanges = true;
      this.state.budgetDataLoaded = false;

      try {
        // Sequential loading to prevent race conditions
        await this.loadExpenditureTypes(value);
        const budgetData = await this.budgetManager.loadBudgetData(value);
        
        if (budgetData) {
          this.state.budgetAmount = budgetData.budgetAmount;
          this.state.ethsiaPistosi = budgetData.ethsiaPistosi;
          this.state.budgetData = budgetData.budgetData;
          this.state.budgetDataLoaded = true;

          const totalAmount = this.calculateTotalAmount();
          await this.budgetManager.updateBudgetIndicators(totalAmount, budgetData.budgetData);
        }
      } catch (error) {
        console.error('Error loading project data:', error);
        ErrorHandler.showError('Failed to load project data');
      } finally {
        // Re-enable inputs
        if (projectSelect) projectSelect.disabled = false;
        if (expTypeSelect) expTypeSelect.disabled = false;
      }
    } catch (error) {
      console.error('Project change error:', error);
      ErrorHandler.showError('Failed to process project selection');
    }
  }

  handleExpenditureTypeChange(value) {
    this.state.expenditure_type = value;
    this.state.hasUnsavedChanges = true;
  }

  handleRecipientInput(input) {
    const { field, index } = input.dataset;
    if (!field || !index) return;

    const idx = parseInt(index);
    if (isNaN(idx)) return;

    // Clear existing timer for this input
    if (this.debounceTimers.has(input)) {
      clearTimeout(this.debounceTimers.get(input));
    }

    const timer = setTimeout(() => {
      let value = input.value;
      const recipient = this.getOrCreateRecipient(idx);

      // Specific field handling
      switch (field) {
        case 'firstname':
        case 'lastname':
          value = value.trim().replace(/[^A-Za-zΑ-Ωα-ωίϊΐόάέύϋΰήώ\s]/g, '');
          break;
        case 'afm':
          value = value.replace(/\D/g, '').slice(0, 9);
          break;
        case 'amount':
          // Keep original input value, just clean non-numeric chars
          const cleanValue = value.replace(/[^\d.,]/g, '').replace(',', '.');
          value = cleanValue;
          recipient.amount = parseFloat(cleanValue) || 0;
          break;
        case 'installment':
          value = Math.max(1, parseInt(value) || 1);
          break;
      }

      this.updateRecipientField(recipient, field, value, input);
      this.state.hasUnsavedChanges = true;

      if (field === 'amount') {
        this.updateTotalAmount();
      }

      // Update input value to show cleaned/formatted data
      if (field === 'amount' && typeof value === 'number') {
        input.value = value.toFixed(2);
      } else {
        input.value = value;
      }
    }, 300);

    this.debounceTimers.set(input, timer);
  }

  getOrCreateRecipient(index) {
    if (!this.state.recipients[index]) {
      this.state.recipients[index] = {
        firstname: '',
        lastname: '',
        afm: '',
        amount: 0,
        installment: 1
      };
    }
    return this.state.recipients[index];
  }

  updateRecipientField(recipient, field, value, input) {
    switch(field) {
      case 'firstname':
        const cleanFirstname = value ? value.toString().trim() : '';
        recipient.firstname = cleanFirstname;
        input.value = cleanFirstname;
        const isValidName = cleanFirstname.length >= 2;
        this.validateField(input, isValidName, "Το όνομα πρέπει να έχει τουλάχιστον 2 χαρακτήρες");
        break;
      case 'amount':
        const parsedAmount = this.parseAmount(value);
        recipient.amount = parsedAmount;
        input.value = parsedAmount || '';

        // Validate amount immediately
        const amountValid = parsedAmount > 0;
        input.classList.toggle('border-red-500', !amountValid);
        const feedback = input.parentElement.querySelector('.invalid-feedback');
        if (feedback) {
          feedback.classList.toggle('hidden', amountValid);
        }
        break;

      case 'afm':
        // Only allow digits and limit to 9 characters
        const cleanAfm = value.replace(/[^\d]/g, '').slice(0, 9);
        recipient.afm = cleanAfm;
        input.value = cleanAfm; // Update input value immediately

        // Validate AFM length
        const afmValid = cleanAfm.length === 9;
        input.classList.toggle('border-red-500', !afmValid);
        const afmFeedback = input.parentElement.querySelector('.invalid-feedback');
        if (afmFeedback) {
          afmFeedback.classList.toggle('hidden', afmValid);
        }
        break;

      case 'installment':
        const installmentValue = Math.max(1, parseInt(value) || 1);
        recipient.installment = installmentValue;
        input.value = installmentValue;
        break;

      case 'lastname':
        const trimmedLastname = value.trim();
        recipient.lastname = trimmedLastname;
        const lastnameValid = trimmedLastname.length >= 2;
        input.classList.toggle('border-red-500', !lastnameValid);
        const lastnameFeedback = input.parentElement.querySelector('.invalid-feedback');
        if (lastnameFeedback) {
          lastnameFeedback.classList.toggle('hidden', lastnameValid);
        }
        break;

      default:
        recipient[field] = value.trim();
    }

    // Update total amount if needed
    if (field === 'amount') {
      this.updateTotalAmount();
    }
  }

  parseAmount(value) {
    if (typeof value === 'number') {
      return Math.max(0, value);
    }
    const stringValue = String(value || '');
    const parsed = parseFloat(stringValue.replace(/[^\d.-]/g, ''));
    return !isNaN(parsed) ? Math.max(0, parsed) : 0;
  }

  updateTotalAmount() {
    const totalAmount = this.calculateTotalAmount();
    if (this.state.budgetData) {
      this.budgetManager.updateBudgetIndicators(totalAmount, this.state.budgetData);
    }
  }

  async loadExpenditureTypes(projectId) {
    try {
      const response = await API.request(`/api/catalog/${projectId}/expenditure-types`);
      const { expenditure_types = [] } = await response.json();

      const expTypeSelect = this.modal?.querySelector("#expTypeSelect");
      if (expTypeSelect) {
        expTypeSelect.innerHTML = `
          <option value="">Select expenditure type...</option>
          ${expenditure_types.map(type => 
            `<option value="${type}">${type}</option>`
          ).join('')}
        `;
      }
    } catch (error) {
      throw new Error('Failed to load expenditure types');
    }
  }

  async loadBudgetData() {
    const budgetData = await this.budgetManager.loadBudgetData(this.state.selectedMIS);
    if (budgetData) {
      this.state.budgetAmount = budgetData.budgetAmount;
      this.state.ethsiaPistosi = budgetData.ethsiaPistosi;
      this.state.budgetData = budgetData.budgetData;
      this.state.budgetDataLoaded = true;

      const totalAmount = this.calculateTotalAmount();
      this.budgetManager.updateBudgetIndicators(totalAmount, this.state.budgetData);
    }
  }

  async handleFormSubmissionSuccess(data) {
    if (!data?.id) throw new Error("Invalid server response");

    await this.updateBudgetAmount();
    this.state.hasUnsavedChanges = false;
    this.hide();
    ErrorHandler.showSuccess("Document created successfully");

    if (this.manager?.loadDocuments) {
      await this.manager.loadDocuments();
    }
  }

  async updateBudgetAmount() {
    const totalAmount = this.calculateTotalAmount();
    await API.request(`/api/budget/${this.state.selectedMIS}/update-amount`, {
      method: "POST",
      body: JSON.stringify({ amount: totalAmount })
    });
  }

  addRecipient() {
    if (this.state.recipients.length >= 10) {
      ErrorHandler.showError("Maximum 10 recipients allowed");
      return;
    }
    const newRecipient = {
      firstname: '',
      lastname: '',
      afm: '',
      amount: '',
      installment: 1
    };
    this.state.recipients.push(newRecipient);
    this.state.hasUnsavedChanges = true;
    this.renderCurrentStep();
  }

  removeRecipient(index) {
    this.state.recipients.splice(index, 1);
    this.state.hasUnsavedChanges = true;
    this.renderCurrentStep();
  }

  handleAttachmentChange(e) {
    const checkbox = e.target;
    const attachment = checkbox.dataset.attachment;

    if (checkbox.checked) {
      if (!this.state.selectedAttachments.includes(attachment)) {
        this.state.selectedAttachments.push(attachment);
      }
    } else {
      this.state.selectedAttachments = this.state.selectedAttachments.filter(a => a !== attachment);
    }

    this.state.hasUnsavedChanges = true;

    // Update selected count
    const countSpan = this.modal?.querySelector('.text-blue-700.rounded-full');
    if (countSpan) {
      countSpan.textContent = `${this.state.selectedAttachments.length} Επιλεγμένα`;
    }
  }

  async previousStep() {
    if (this.currentStep > 0) {
      this.currentStep--;
      await this.renderCurrentStep();
      this.updateProgress();
    }
  }

  async nextStep() {
    if (this.state.loading) return;

    try {
      if (!(await this.validateCurrentStep())) return;

      if (this.currentStep < 3) {
        this.currentStep++;
        await this.renderCurrentStep();
        this.updateProgress();
      } else {
        await this.submitForm();
      }
    } catch (error) {
      ErrorHandler.showError(error.message);
    }
  }

  setupKeyboardShortcuts() {
    document.addEventListener("keydown", (e) => {
      if (!this.modal?.classList.contains("active")) return;
      if (e.key === "Escape") this.hide();
      if (e.key === "Enter" && e.ctrlKey) this.nextStep();
    });
  }

  async show() {
    try {
      this.currentStep = 0;
      this.state = this.getInitialState();
      if (!(await this.initialize())) throw new Error("Failed to initialize modal");
      await super.show();
      this.updateProgress();
    } catch (error) {
      console.error("Error showing modal:", error);
      ErrorHandler.showError(error.message);
    }
  }

  updateProgress() {
    const progress = ((this.currentStep + 1) / 4) * 100;
    requestAnimationFrame(() => {
      const progressBar = this.modal?.querySelector(".bg-blue-600");
      if (progressBar) {
        progressBar.style.width = `${progress}%`;
      }
    });
  }

  updateSubmitButton(loading) {
    const submitBtn = this.modal?.querySelector(".next-step");
    if (submitBtn) {
      submitBtn.disabled = loading;
      submitBtn.innerHTML = loading
        ? '<i class="fas fa-spinner fa-spin mr-2"></i>Creating...'
        : 'Create<i class="fas fa-arrow-right ml-2"></i>';
    }
  }

  async renderCurrentStep() {
    if (!this.modal) {
      throw new Error("Modal not initialized");
    }

    const steps = [
      this.renderUnitStep.bind(this),
      this.renderProjectStep.bind(this),
      this.renderRecipientsStep.bind(this),
      this.renderAttachmentsStep.bind(this)
    ];

    try {
      // Pre-load budget data if needed
      if (this.currentStep === 2 && !this.state.budgetDataLoaded && this.state.selectedMIS) {
        await this.loadBudgetData();
        this.state.budgetDataLoaded = true;
      }

      const content = await steps[this.currentStep]();
      await this.setContent(await this.wrapStepContent(content));

      // Give DOM time to update before setting up handlers
      await new Promise(resolve => setTimeout(resolve, 100));
      await this.setupStepHandlers();
      this.updateProgress();

      // Update budget indicators if needed
      if (this.currentStep === 2 && this.state.budgetData) {
        await new Promise(resolve => setTimeout(resolve, 0));
        this.budgetManager.updateBudgetIndicators(
          this.calculateTotalAmount(),
          this.state.budgetData
        );
      }
    } catch (error) {
      console.error("Error rendering step:", error);
      ErrorHandler.showError(error.message);
    }
  }

  async wrapStepContent(content) {
    try {
      const response = await fetch('/generated-documents/templates/createDocumentModal.html');
      const template = await response.text();
      const doc = new DOMParser().parseFromString(template, 'text/html');

      // Update components
      const components = {
        '.bg-blue-600': () => `${((this.currentStep + 1) / 4) * 100}%`,
        '#steps-container': () => this.createStepIndicators(),
        '#step-title': () => this.stepTitles[this.currentStep],
        '#step-content': () => content,
        '#prev-button-container': () => this.createPrevButton(),
        '.next-step': (el) => {
          el.textContent = this.currentStep === 3 ? 'Δημιουργία' : 'Επόμενο';
          el.classList.toggle('opacity-50', this.state.loading);
          el.classList.toggle('cursor-not-allowed', this.state.loading);
        }
      };

      for (const [selector, update] of Object.entries(components)) {
        const element = doc.querySelector(selector);
        if (element) {
          const result = update(element);
          if (typeof result === 'string') {
            if (selector.startsWith('.')) {
              element.style.width = result;
            } else {
              element.innerHTML = result;
            }
          }
        }
      }

      return doc.body.innerHTML;
    } catch (error) {
      console.error('Error wrapping step content:', error);
      throw new Error('Failed to wrap step content');
    }
  }

  createPrevButton() {
    return this.currentStep > 0 
      ? `<button class="prev-step px-6 py-3 text-gray-600 hover:text-gray-800 bg-gray-100/80 hover:bg-gray-200/80 rounded-lg transition-all duration-200 flex items-center font-medium shadow-sm hover:shadow backdrop-blur-sm">
          <i class="fas fa-arrow-left mr-2"></i>Προηγούμενο
         </button>`
      : '';
  }

  createStepIndicators() {
    return `
      <div class="flex items-center gap-1 bg-gray-50/50 p-1.5 rounded-lg border border-gray-100/80">
        ${this.stepTitles.map((step, index) => `
          <div class="flex items-center ${index !== 0 ? 'ml-2' : ''} ${index !== this.stepTitles.length - 1 ? 'mr-2' : ''}">
            <div class="relative group">
              <div class="flex items-center gap-2 px-3 py-1.5 rounded-md transition-all duration-200 ${
                index === this.currentStep 
                  ? "bg-white text-blue-600 shadow-sm ring-1 ring-blue-100" 
                  : index < this.currentStep
                  ? "text-green-600 hover:bg-white/60"
                  : "text-gray-500 hover:bg-white/60"
              }">
                <div class="w-5 h-5 rounded-full flex items-center justify-center text-xs font-medium ${
                  index === this.currentStep 
                    ? "bg-blue-100/80" 
                    : index < this.currentStep
                    ? "bg-green-100/80"
                    : "bg-gray-100"
                }">
                  ${index < this.currentStep ? '<i class="fas fa-check text-[10px]"></i>' : index + 1}
                </div>
                <span class="text-xs font-medium whitespace-nowrap">${step}</span>
              </div>
            </div>
            ${index !== this.stepTitles.length - 1 
              ? `<div class="ml-1 w-2 h-px bg-gray-200"></div>` 
              : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  async renderUnitStep() {
    try {
      const user = getUserFromToken();
      if (!user) throw new Error("User not authenticated");

      const userUnits = Array.isArray(user.units) ? user.units : [];
      if (!userUnits.length) throw new Error("No units assigned to user");

      if (userUnits.length === 1) {
        this.state.unit = userUnits[0];
      }

      return `
        <div class="space-y-4">
          <label class="block text-sm font-medium text-gray-700">Select Unit</label>
          <select id="unitSelect" class="w-full p-2 border rounded">
            ${userUnits.length > 1 ? '<option value="">Select a unit...</option>' : ""}
            ${userUnits.map(unit => `
              <option value="${unit}" ${unit === this.state.unit ? "selected" : ""}>
                ${unit}
              </option>
            `).join("")}
          </select>
        </div>
      `;
    } catch (error) {
      console.error("Error loading units:", error);
      return '<p class="text-red-600">Failed to load units</p>';
    }
  }

  async renderProjectStep() {
    const unit = this.state.unit;
    if (!unit) {
      return '<p class="text-red-600">Please select a unit first</p>';
    }

    try {
      await new Promise(resolve => setTimeout(resolve, 100)); // Ensure DOM is ready
      const token = await getAuthToken();
      const response = await fetch(
        `/api/catalog?unit=${encodeURIComponent(unit)}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      if (!response.ok) throw new Error("Failed to load projects");
      const result = await response.json();
      const projects = result.data || [];

      const selectedProject = projects.find(
        (p) => p.mis === this.state.project,
      );
      let expenditureTypes = [];

      if (selectedProject) {
        try {
          this.state.selectedNA853 = selectedProject.na853;
          this.state.budgetAmount = parseFloat(selectedProject.budget_na853) || 0;
          const response = await fetch(
            `/api/catalog/${selectedProject.mis}/expenditure-types`,
            {
              headers: {
                Authorization: `Bearer ${await getAuthToken()}`,
              },
            },
          );
          const { expenditure_types } = await response.json();
          expenditureTypes = expenditure_types || [];

          // Load budget data when project is selected
          await this.loadBudgetData();
        } catch (error) {
          console.error('Error loading project details:', error);
          throw new Error('Failed to load project details');
        }
      }

      return `
        <div class="space-y-6 w-full">
          ${this.state.budgetData ? `
          <div class="w-full bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl border border-blue-100/50 shadow-lg mb-6">
            <div class="budget-indicators"></div>
          </div>` : ''}
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Select Project</label>
            <select id="projectSelect" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500">
              <option value="">Select a project...</option>
              ${projects
                .map(
                  (p) => `
                <option value="${p.mis}" data-na853 ="${p.na853}" data-budget="${p.budget_na853}">${p.na853} - ${p.event_description || "Unnamed Project"}</option>
              `,
                )
                .join("")}
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700 mb-2">Expenditure Type</label>
            <select id="expTypeSelect" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500">
              <option value="">Select expenditure type...</option>
              ${expenditureTypes.map((type) => `<option value="${type}">${type}</option>`).join("")}
            </select>
          </div>
        </div>
      `;
    } catch (error) {
      console.error("Error loading projects:", error);
      return `<p class="text-red-600">Failed to load projects: ${error.message}</p>`;
    }
  }

  async calculateMonthlyTotal() {
    try {
      const response = await fetch(
        `/api/budget/${this.state.selectedMIS}/monthly-total`,
        {
          headers: {
            Authorization: `Bearer ${await getAuthToken()}`,
          },
        },
      );
      const data = await response.json();
      return parseFloat(data.total) || 0;
    } catch (error) {
      console.error("Error calculating monthly total:", error);
      return 0;
    }
  }

  async renderRecipientsStep() {
    try {
      if (!this.state.budgetDataLoaded) {
        await this.loadBudgetData();
        this.state.budgetDataLoaded = true;
      }

      const recipients = this.state.recipients || [];
      const totalAmount = this.calculateTotalAmount();

      // Update budget indicators
      this.budgetManager.updateBudgetIndicators(totalAmount, this.state.budgetData);

      // Update recipient count and total amount
      requestAnimationFrame(() => {
        const countEl = document.getElementById('recipientCount');
        const totalEl = document.getElementById('totalAmount');
        if (countEl) countEl.textContent = recipients.length;
        if (totalEl) totalEl.textContent = new Intl.NumberFormat('el-GR', {
          style: 'currency',
          currency: 'EUR'
        }).format(totalAmount);
      });

      // Update recipients table
      const recipientsTableBody = document.getElementById('recipientsTableBody');
      if (recipientsTableBody) {
        recipientsTableBody.innerHTML = '';
        for (let i = 0; i < recipients.length; i++) {
          const row = document.createElement('tr');
          row.innerHTML = this.createRecipientRow(recipients[i], i);
          recipientsTableBody.appendChild(row);
        }
      }

      return `
      <div class="space-y-6">
        <div id="budget-indicators-container" class="bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl border border-blue-100/50 shadow-lg">
        </div>


        <div class="bg-white rounded-xl border border-gray-200/75 shadow-sm p-6">
          <div class="flex justify-between items-center mb-6">
          <div class="flex justify-between items-center">
            <div>
              <h3 class="text-xl font-bold text-gray-800">Παραλήπτες</h3>
              <p class="text-sm text-gray-600">Προσθέστε έως 10 παραλήπτες για αυτό το έγγραφο</p>
            </div>
            <button id="addRecipientBtn" 
                    class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200 flex items-center space-x-2">
              <i class="fas fa-plus-circle"></i>
              <span class="font-medium">Προσθήκη Παραλήπτη</span>
            </button>
          </div>
          </div>
          <div class="overflow-x-auto overflow-y-auto max-h-[calc(100vh-24rem)] rounded-xl border border-gray-200/75 shadow-sm bg-white">
        <table class="min-w-full bg-white table-fixed divide-y divide-gray-200">
          <thead class="sticky top-0 z-10">
            <tr class="bg-gradient-to-r from-blue-50 to-white">
              <th class="px-16 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider bg-white">#</th> 
              <th class="px-6 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Όνομα</th> 
              <th class="px-14 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Επώνυμο</th> 
              <th class="px-24 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider">ΑΦΜ</th> 
              <th class="px-14 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Ποσό</th> 
              <th class="px-6 py-4 border-b border-r text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Δόση</th> 
              <th class="px-14 py-4 border-b text-center text-xs font-bold text-gray-700 uppercase tracking-wider">Ενέργειες</th> 
            </tr>
          </thead>
          <tbody>
            ${recipients
              .map(
                (recipient, index) => `
              <tr class="hover:bg-gray-50 transition-colors">
                <td class="w-12 px-2 py-3 border-b border-r text-sm font-medium text-gray-900 text-center">
                  <span class="inline-flex items-center justify-center h-7 w-7 rounded-full bg-blue-50 text-blue-600 font-semibold text-sm">
                    ${index + 1}
                  </span>
                </td>
                <td class="px-6 py-3 border-b border-r">
                  <div class<div class="relative group">
                    <input type="text" 
                           value="${recipient.firstname || ""}" 
                           class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm recipient-input" 
                           data-field="firstname" 
                           data-index="${index}"
                           placeholder="Όνομα"
                           autocomplete="given-name"
                           aria-label="First name for recipient ${index + 1}">
                    <div class="invalid-feedback hidden text-red-500 text-xs mt-1">At least 2 characters required.</div>
                  </div>
                </td>
                <td class="px-14 py-3 border-b border-r">
                  <div class="relative">
                    <input type="text" 
                           value="${recipient.lastname || ""}" 
                           class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm recipient-input" 
                           data-field="lastname" 
                           data-index="${index}"
                           placeholder="Επώνυμο"
                           autocomplete="family-name"
                           aria-label="Last name for recipient ${index + 1}">
                    <div class="invalid-feedback hidden text-red-500 text-xs mt-1">At least 2 characters required.</div>
                  </div>
                </td>
                <td class="px-24 py-3 border-b border-r">
                  <div class="relative"><div class="relative">
                    <input type="text" 
                           value="${recipient.afm || ""}" 
                           class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm font-mono recipient-input" 
                           data-field="afm" 
                           data-index="${index}"
                           maxlength="9"
                           placeholder="ΑΦΜ"
                           autocomplete="off"
                           aria-label="AFM for recipient ${index + 1}">
                    <div class="invalid-feedback hidden text-red-500 text-xs mt-1">AFM must be 9 digits long.</div>
                  </div>
                </td>
                <td class="px-14 py-3 border-b border-r">
                  <div class="relative">
                    <input type="number" 
                           value="${recipient.amount || ""}" 
                           class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm text-right recipient-input" 
                           data-field="amount" 
                           data-index="${index}"
                           step="0.01"
                           placeholder="0.00"
                           aria-label="Amount for recipient ${index + 1}">
                    <div class="invalid-feedback hidden text-red-500 text-xs mt-1">Amount must be greater than 0.</div>
                  </div>
                </td>
                <td class="px-6 py-3 border-b border-r w-24">
                  <div class="relative">
                    <input type="number" 
                           value="${recipient.installment || ""}"
                           class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm text-center recipient-input" 
                           data-field="installment" 
                           data-index="${index}"
                           min="1"
                           placeholder="1"
                           aria-label="Installment for recipient ${index + 1}">
                  </div>
                </td>
                <td class="px-14 py-4 border-b text-center">
                  <button class="delete-recipient text-red-600 hover:text-red-800 p-1" data-index="${index}">
                    <i class="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            `,
              )
              .join("")}
          </tbody>
        </table>
      </div>
      </div>
    `;
    } catch (error) {
      console.error("Error rendering recipients step:", error);
      return `<p class="text-red-600">Failed to render recipients: ${error.message}</p>`;
    }
  }

  createRecipientRow(recipient, index) {
    return `
      <tr class="hover:bg-gray-50 transition-colors">
        <td class="w-12 px-2 py-3 border-b border-r text-sm font-medium text-gray-900 text-center">
          <span class="inline-flex items-center justify-center h-7 w-7 rounded-full bg-blue-50 text-blue-600 font-semibold text-sm">
            ${index + 1}
          </span>
        </td>
        <td class="px-6 py-3 border-b border-r">
          <div class="relative group">
            <input type="text" 
                   value="${recipient.firstname || ""}" 
                   class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm recipient-input" 
                   data-field="firstname" 
                   data-index="${index}"
                   placeholder="Όνομα"
                   autocomplete="given-name"
                   aria-label="First name for recipient ${index + 1}">
            <div class="invalid-feedback hidden text-red-500 text-xs mt-1">At least 2 characters required.</div>
          </div>
        </td>
        <td class="px-14 py-3 border-b border-r">
          <div class="relative">
            <input type="text" 
                   value="${recipient.lastname || ""}" 
                   class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm recipient-input" 
                   data-field="lastname" 
                   data-index="${index}"
                   placeholder="Επώνυμο"
                   autocomplete="family-name"
                   aria-label="Last name for recipient ${index + 1}">
            <div class="invalid-feedback hidden text-red-500 text-xs mt-1">At least 2 characters required.</div>
          </div>
        </td>
        <td class="px-24 py-3 border-b border-r">
          <div class="relative">
            <input type="text" 
                   value="${recipient.afm || ""}" 
                   class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm font-mono recipient-input" 
                   data-field="afm" 
                   data-index="${index}"
                   maxlength="9"
                   placeholder="ΑΦΜ"
                   autocomplete="off"
                   aria-label="AFM for recipient ${index + 1}">
            <div class="invalid-feedback hidden text-red-500 text-xs mt-1">AFM must be 9 digits long.</div>
          </div>
        </td>
        <td class="px-14 py-3 border-b border-r">
          <div class="relative">
            <input type="number" 
                   value="${recipient.amount || ""}" 
                   class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm text-right recipient-input" 
                   data-field="amount" 
                   data-index="${index}"
                   step="0.01"
                   placeholder="0.00"
                   aria-label="Amount for recipient ${index + 1}">
            <div class="invalid-feedback hidden text-red-500 text-xs mt-1">Amount must be greater than 0.</div>
          </div>
        </td>
        <td class="px-6 py-3 border-b border-r w-24">
          <div class="relative">
            <input type="number" 
                   value="${recipient.installment || ""}"
                   class="w-full px-3 py-2 bg-white/50 border border-gray-200 rounded-md hover:border-blue-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition-all text-sm text-center recipient-input" 
                   data-field="installment" 
                   data-index="${index}"
                   min="1"
                   placeholder="1"
                   aria-label="Installment for recipient ${index + 1}">
          </div>
        </td>
        <td class="px-14 py-4 border-b text-center">
          <button class="delete-recipient text-red-600 hover:text-red-800 p-1" data-index="${index}">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      </tr>
    `;
  }

  async renderAttachmentsStep() {
    try {
      const response = await fetch(`/api/documents/attachments/${encodeURIComponent(this.state.expenditure_type)}/${encodeURIComponent(this.state.recipients?.[0]?.installment || 1)}`, {
        headers: {
          Authorization: `Bearer ${await getAuthToken()}`
        }
      });

      if (!response.ok) throw new Error('Failed to fetch attachments');
      const data = await response.json();
      const attachments = data?.attachments || ['Διαβιβαστικό', 'ΔΚΑ'];

      this.state.selectedAttachments = this.state.selectedAttachments || [];

      return `
        <div class="space-y-6">
          <div class="flex justify-between items-center">
            <div>
              <h3 class="text-lg font-semibold text-gray-900">Συνημμένα Έγγραφα</h3>
              <p class="text-sm text-gray-500 mt-1">Επιλέξτε τα έγγραφα που θα συμπεριληφθούν στο διαβιβαστικό</p>
            </div>
            <span class="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium">
              ${this.state.selectedAttachments.length} Επιλεγμένα
            </span>
          </div>

          <div class="space-y-4">
            ${attachments.map((attachment, index) => {
              const isSelected = this.state.selectedAttachments.includes(attachment);
              
              return `
                <div class="flex items-center p-4 border rounded-lg ${isSelected ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'}">
                  <input type="checkbox" 
                         id="attachment-${index}"
                         class="attachment-checkbox w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                         data-attachment="${attachment}"
                         ${isSelected ? 'checked' : ''}>
                  <label for="attachment-${index}" class="ml-3 block text-sm font-medium ${isSelected ? 'text-blue-700' : 'text-gray-700'}">
                    ${attachment}
                  </label>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    } catch (error) {
      console.error("Error loading attachments:", error);
      return `<p class="text-red600">Failed to load attachments: ${error.message}</p>`;
    }
  }

  async handleSubmitResponse(result) {
    this.showSuccess("Document created successfully");
    this.hide();
    if (this.manager?.loadDocuments) {
      await this.manager.loadDocuments();
    }
  }

  async submitFormData(formData) {
    const token = await getAuthToken();
    if (!token) throw new Error("Authentication required");

    const response = await fetch("/api/documents/generated", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to create document");
    }

    return response.json();
  }
  async setupStepHandlers() {
    const unitSelect = this.modal?.querySelector('#unitSelect');
    const projectSelect = this.modal?.querySelector('#projectSelect');
    const expTypeSelect = this.modal?.querySelector('#expTypeSelect');

    if (this.currentStep === 0 && unitSelect) {
      unitSelect.addEventListener('change', (e) => {
        this.state.unit = e.target.value;
        this.state.hasUnsavedChanges = true;
      });
    }

    if (this.currentStep === 1) {
      if (projectSelect) {
        projectSelect.addEventListener('change', (e) => this.handleProjectChange(e.target.value));
      }
      if (expTypeSelect) {
        expTypeSelect.addEventListener('change', (e) => this.handleExpenditureTypeChange(e.target.value));
      }
    }

    if (this.currentStep === 2) {
      const inputs = this.modal?.querySelectorAll('.recipient-input');
      inputs?.forEach(input => {
        input.addEventListener('input', (e) => this.handleRecipientInput(e.target));
      });
    }
  }

  cleanup() {
    this.eventHandlers.forEach((handler, event) => {
      this.modal?.removeEventListener(event, handler);
    });
    this.eventHandlers.clear();
    this.debounceTimers.forEach(timer => clearTimeout(timer));
    this.debounceTimers.clear();
    this.state = this.getInitialState();
    this.initialized = false;
  }
  validateField(input, isValid, message) {
    input.classList.toggle('border-red-500', !isValid);
    const feedback = input.parentElement.querySelector('.invalid-feedback');
    if (feedback) {
      feedback.textContent = message;
      feedback.classList.toggle('hidden', isValid);
    }
  }

  highlightInvalidField(index, field) {
    const input = this.modal?.querySelector(`input[data-field="${field}"][data-index="${index}"]`);
    if (input) {
      input.classList.add('border-red-500', 'bg-red-50');
      input.addEventListener('input', function onInput() {
        this.classList.remove('border-red-500', 'bg-red-50');
        this.removeEventListener('input', onInput);
      });
      input.focus();
    }
  }
}