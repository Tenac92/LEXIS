import React, { useState, useEffect } from 'react';
import { DocumentUIManager } from './DocumentUIManager';
import { RecipientManager } from './RecipientManager';
import { OrthiEpanalipsiManager } from './OrthiEpanalipsiManager';
import { ProtocolManager } from './ProtocolManager';
import { ErrorHandler } from '../../utils/errorHandler';
import { TokenManager } from '../../utils/tokenManager';
import { createHeader } from '../../components/header';

export default function GeneratedDocumentsManager() {
  const [state, setState] = useState({
    initialized: false,
    loading: false,
    error: null,
    currentView: 'grid'
  });

  const [managers] = useState({
    uiManager: new DocumentUIManager(),
    recipientManager: new RecipientManager(),
    orthiManager: new OrthiEpanalipsiManager(),
    protocolManager: new ProtocolManager()
  });

  const [userData, setUserData] = useState({
    userId: null,
    userRole: 'user',
    userUnits: [],
    userName: '',
    userDepartment: ''
  });

  useEffect(() => {
    const initializeManagers = async () => {
      try {
        setState(prev => ({ ...prev, loading: true }));
        const isAuthenticated = await validateSession();

        if (!isAuthenticated) {
          window.location.href = '/index.html';
          return;
        }

        const headerElement = createHeader();
        if (headerElement) {
          document.body.insertBefore(headerElement, document.body.firstChild);
        }

        await managers.uiManager.initializeUI();
        await managers.recipientManager.initialize();

        setState(prev => ({ ...prev, initialized: true }));
      } catch (error) {
        console.error('Initialization error:', error);
        ErrorHandler.showError(error.message);
      } finally {
        setState(prev => ({ ...prev, loading: false }));
      }
    };

    initializeManagers();

    return () => {
      // Cleanup
      Object.values(managers).forEach(manager => {
        if (manager.cleanup) manager.cleanup();
      });
    };
  }, []);

  const validateSession = async () => {
    try {
      const tokenManager = TokenManager.getInstance();
      const token = await tokenManager.getToken();

      if (!token) {
        console.error('No auth token found');
        return false;
      }

      const parsedToken = tokenManager.parseToken(token);
      if (!parsedToken) {
        console.error('Token parsing failed');
        return false;
      }

      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, '=');

      const userData = JSON.parse(window.atob(padded));
      if (!userData?.userId) {
        console.error('Missing user ID in token');
        return false;
      }

      setUserData({
        userId: userData.userId,
        userRole: userData.role || 'user',
        userUnits: Array.isArray(userData.units) ? userData.units : [],
        userName: userData.name,
        userDepartment: userData.department
      });

      return true;
    } catch (error) {
      console.error('Session validation error:', error);
      localStorage.removeItem('authToken');
      return false;
    }
  };

  if (!state.initialized) {
    return <div>Loading...</div>;
  }

  return (
    <div className="generated-documents">
      <div id="loadingOverlay" className={`fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center ${state.loading ? '' : 'hidden'}`}>
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
      <div id="documentsTable"></div>
      <div id="errorMessage" className="hidden fixed top-4 right-4 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded shadow-lg">
        <div id="errorText"></div>
      </div>
    </div>
  );
}