import React, { createContext, useState, useContext, useEffect } from 'react';
import { API } from '../utils/api.js';
import { TokenManager } from '../utils/tokenManager.js';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refreshToken = async () => {
    try {
      const token = TokenManager.getStoredToken();
      if (!token) {
        throw new Error('No token available');
      }

      const response = await API.request('/auth/refresh', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response?.token) {
        TokenManager.setToken(response.token);
        return response;
      }
      throw new Error('Invalid refresh token response');
    } catch (err) {
      console.error('Token refresh failed:', err);
      TokenManager.clearToken();
      setUser(null);
      // setIsAuthenticated(false); //This line was not present in the original code.  It's unclear where isAuthenticated is declared.
      throw err;
    }
  };

  const login = async (credentials) => {
    try {
      const response = await API.request('/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          email: credentials.email.trim(),
          password: credentials.password.trim()
        })
      });

      if (response?.token && response?.user) {
        TokenManager.setToken(response.token);
        setUser(response.user);
        return response;
      }
      throw new Error('Invalid login response');
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const logout = () => {
    TokenManager.clearToken();
    setUser(null);
    window.location.href = '/login';
  };

  useEffect(() => {
    const initAuth = async () => {
      try {
        const token = TokenManager.getStoredToken();
        if (!token) {
          setLoading(false);
          return;
        }

        const response = await API.request('/auth/profile', {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        if (response?.user) {
          setUser(response.user);
        } else {
          await refreshToken();
        }
      } catch (err) {
        console.error('Auth initialization failed:', err);
        TokenManager.clearToken();
        setError(err.message); // Added error handling
      } finally {
        setLoading(false);
      }
    };

    initAuth();
  }, []);

  const value = {
    user,
    loading,
    error,
    login,
    logout,
    isAuthenticated: !!user
  };

  return React.createElement(AuthContext.Provider, { value }, children);
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};