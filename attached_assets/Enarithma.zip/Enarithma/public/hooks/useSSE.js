
import { useEffect, useRef } from 'react';
import { sseService } from '../utils/sseService.js';

export function useSSE(endpoint, handlers = {}) {
  const eventSourceRef = useRef(null);

  useEffect(() => {
    const connect = async () => {
      eventSourceRef.current = await sseService.createConnection(endpoint, handlers);
    };
    connect();

    return () => {
      if (eventSourceRef.current) {
        sseService.closeConnection(endpoint);
      }
    };
  }, [endpoint]);

  return eventSourceRef.current;
}
