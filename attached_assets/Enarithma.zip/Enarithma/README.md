
# Document Management System

A comprehensive web-based document management system built with Node.js and Express for handling document generation, user management, project catalog operations, and budget tracking.

## Core Features

- **User Authentication & Authorization**: Secure JWT-based authentication system
- **Document Management**: 
  - Generate and manage documents
  - Support for multiple document templates
  - Document validation and formatting
- **Project Catalog**: 
  - Project tracking and management
  - CSV bulk import/export
  - Project status monitoring
- **Budget Management**:
  - Budget allocation tracking
  - Real-time budget updates
  - Notification system for budget changes
- **User Management**:
  - Role-based access control
  - User profile management
  - Unit/Department management
- **Statistical Dashboard**:
  - Real-time data visualization
  - Performance metrics
  - Project status overview
- **Audit Logging**: Comprehensive activity tracking

## Technology Stack

### Frontend
- React.js
- Tailwind CSS
- Vite
- Context API for state management

### Backend
- Node.js
- Express.js
- PostgreSQL with Supabase
- JWT Authentication
- Server-Sent Events (SSE)

## Project Structure

```
├── /public/                 # Frontend React application
│   ├── /assets/            # Static assets
│   ├── /components/        # Reusable UI components
│   ├── /contexts/          # React contexts
│   ├── /hooks/             # Custom React hooks
│   └── /utils/             # Frontend utilities
├── /src/                   # Backend source code
│   ├── /config/           # Configuration files
│   ├── /controllers/      # API route controllers
│   ├── /middleware/       # Express middleware
│   ├── /models/          # Database models
│   └── /utils/           # Backend utilities
```

## Setup & Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Set up environment variables in `.env`:
```env
PORT=3000
JWT_SECRET=your_jwt_secret
DATABASE_URL=your_database_url
SESSION_SECRET=your_session_secret
```

4. Start the development server:
```bash
npm run dev
```

## API Routes

### Authentication
- `POST /auth/login` - User login
- `POST /auth/logout` - User logout

### Users
- `GET /api/users` - List users
- `POST /api/users` - Create user
- `PUT /api/users/:id` - Update user

### Documents
- `GET /api/documents` - List documents
- `POST /api/documents` - Create document
- `GET /api/documents/generated` - List generated documents

### Project Catalog
- `GET /api/catalog` - List projects
- `POST /api/catalog` - Add project
- `PUT /api/catalog/:id` - Update project
- `POST /api/catalog/csv-upload` - Bulk import projects

### Budget
- `GET /api/budget` - Get budget information
- `POST /api/budget/updates` - Track budget changes
- `GET /api/budget/notifications` - Get budget notifications

## Security Features

- JWT token authentication
- Rate limiting
- CORS protection
- Helmet security headers
- Input validation
- XSS protection
- Session management

## Development

The application uses Vite for development with hot module replacement (HMR) enabled. The backend uses nodemon for automatic server restart during development.

## Error Handling

The application implements a comprehensive error handling system with:
- Global error middleware
- API error handler
- Frontend error boundary
- Audit logging

## License

Private software. All rights reserved.
